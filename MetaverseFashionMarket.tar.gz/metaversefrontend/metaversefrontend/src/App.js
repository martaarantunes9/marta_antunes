import { Routes, Route, useLocation } from "react-router-dom";

import Welcome from "./components/Layout/Welcome/Welcome";
import Navbar from "./components/Layout/Navbar/Navbar";
import Collection from "./components/Collection/Collection";
import SignUp from "./components/Layout/SignUp/SignUp";
import Login from "./components/Layout/Login/Login";
import ForgotPassword from "./components/Layout/Forgot Password/ForgotPassword";
import AboutUs from "./components/Layout/AboutUs/AboutUs";
import Basket from "./components/Layout/Basket/Basket";
import Checkout from "./components/Layout/Checkout/Checkout";
import Profile from "./components/Layout/Profile/Profile";
import Footer from "./components/Layout/Footer/Footer";

import styles from "./App.module.css";

// import Carousel from './components/Layout/Carousel/Carousel';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faSearch } from '@fortawesome/free-solid-svg-icons';

import { useEffect, useState } from "react";

function App() {
  const location = useLocation();

  const [num, setNum] = useState();
  const [basket, setBasket] = useState();

  async function verifyBasket() {
    const collec = await fetch("/user/basket", {
      method: "GET",
      headers: {
        authorization: `a ${localStorage.getItem("token")}`,
      },
    });
    const res = await collec.json();
    setBasket(res);
    console.log(res.basket.length);
    setNum(res.basket.length);
  }

  useEffect(() => {
    verifyBasket();
    
  }, []);

  const totalProducts = () => {
    return num;
  };

  const sendToBasket = async (product) => {
    //a cada clique aqui, devemos guardar no Mongo
    const res = await fetch("/basket", {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        authorization: `a ${localStorage.getItem("token")}`,
      },
      body: JSON.stringify({
        basket: product,
      }),
    });
    const resJson = await res.json();
    await verifyBasket();
  };

  return (
    <div>
         {location.pathname !== "/" && (
        <div>
          <Navbar total={totalProducts} />
                 {(location.pathname !== "/signup") && <div className={styles.banner}></div>
         } 
        </div>
      )}
      {/* <Carousel title="Popular" /> */}
      {/* <h1 id="collection">Collection</h1> */}
      <div className={styles.content}> 
      <Routes>
        <Route exact path="/" element={<Welcome />}></Route>
        <Route path="/collection" element={<Collection add={sendToBasket} />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/login" element={<Login />} />
        <Route path="/forgotPassword" element={<ForgotPassword />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/basket" element={<Basket />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/profile" element={<Profile />} />
      </Routes>
      </div>
      <Footer />
    </div>
  );
}

export default App;

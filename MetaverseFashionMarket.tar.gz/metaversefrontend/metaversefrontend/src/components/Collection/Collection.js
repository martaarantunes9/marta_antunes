import React, { useState, useRef, useEffect } from "react"
import Carousel from "../Layout/Carousel/Carousel";
import Search from "../Layout/Search/Search";
import styles from './Collection.module.css';
import Sticky from 'react-sticky-el';

const Collection = ({ add }) => {
  const [filtered, setFiltered] = useState(null);
  const [collection, setCollection] = useState();
  const [text, setText] = useState("");
  const [avatar, setAvatar] = useState([])

  ///////////AVATAR/////////////////////
  async function verifyAvatar(token) {
    const collec = await fetch("/user/avatar", {
      method: "GET",
      headers: {
        "authorization": `a ${localStorage.getItem('token')}`
      }
    });
    const res = await collec.json();
    setAvatar(res.avatar);
  }

  useEffect(() => {
    verifyAvatar()
  }, [])


  const tryOnAvatar = async (product) => {
    //a cada clique aqui, devemos guardar no Mongo


    const res = await fetch("/user/avatar", {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        "authorization": `a ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({
        avatar: product
      }
      )
    })
    const resJson = await res.json();
    await verifyAvatar();

  }
  const removeItems = async (avatar) => {
    const check = await fetch("/user/clear", {
        method: "DELETE",
        headers: {
            "Authorization": `a ${localStorage.getItem('token')}`
        }
    })
    const res = await check.json();
    setAvatar([]);
}





  /////////////AVATAR/////////////////////
  useEffect(() => {
    getCollection();
  }, []);

  async function getCollection() {
    const collec = await fetch("/collection");
    const res = await collec.json();
    setCollection(res);
  }

  useEffect(() => {
    if (filtered === null) {
      // text.current.value = "";
    }
  }, []);

  const filterProducts = (name) => {
    setFiltered(
      collection.types.map((prod) =>
        prod.products.filter((product) =>
          product.Name.toLowerCase().includes(name)
        )
      )
    );
  };

  const clearFilter = () => {
    setFiltered(null);
  };

  const onChange = (e) => {
    if (text.current.value !== "") {
      filterProducts(e.target.value);
    } else {
      clearFilter();
    }
  };

  if (!collection) {
    return null
  }
  if (!avatar) {
    return null
}

  return (
    <div className={styles.father}>
      <div>
        <Search onChange={onChange} text={text} />
      </div>

      <div >
        {filtered !== null ? (
          filtered.map((filteredProduct, i) => {
            <Carousel
              key={i}
              add={add}
              collection={filteredProduct}
              tryOnAvatar={tryOnAvatar}
            />;
          }))
          : (
            <Carousel
              add={add}
              collection={collection[0]}
              tryOnAvatar={tryOnAvatar}
            />
          )}
      </div>
    
      <Sticky >
     <div className={styles.sticky}>
          <div className={styles.visualizador}>
            <img src={'/avatarImg/avatar_1.png'} style={{height:700 }} />
            {avatar && avatar.map((product, i) => (
              <div key={i}>
                <img className={styles.tryOn} src={product.imgAvatar}  style={{height:700}}/>
              </div>))}
              <button className={styles.getNaked} onClick={()=> removeItems(avatar)}>Get naked !</button>
          </div>
      </div>
      </Sticky>
    </div>

  );

};

export default Collection;
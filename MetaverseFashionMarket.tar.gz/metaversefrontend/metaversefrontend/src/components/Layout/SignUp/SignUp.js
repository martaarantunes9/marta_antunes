import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import InputButton from "../InputButton/InputButton";
import gif from "../../../imagemBanner/gif.webp";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faEye,
  faEyeSlash,
  faCheckCircle,
  faTimesCircle,
} from "@fortawesome/free-solid-svg-icons";
import styles from "../SignUp/SignUp.module.css";

const SignUp = () => {
  let navigate = useNavigate();

  const [visiblePassword, setVisiblePassword] = useState(false);
  const [visiblePasswordConfirmation, setVisiblePasswordConfirmation] =
    useState(false);
  const [signUp, setSignUp] = useState({
    name: "",
    avatarName: "",
    email: "",
    password: "",
    passwordConfirmation: "",
    gender: "",
    acceptsTerms: false,
    subscribesNewsletter: false,
    basket: [],
    avatar: []
  });

  const [error, setError] = useState({
    name: "",
    avatarName: "",
    email: "",
    password: "",
    gender: "",
    acceptsTerms: "",
  });

  const [fail, setFail] = useState("");
  const [loading, setLoading] = useState(false);

  const [erros, setErros] = useState({
    name: "Please, insert your name",
    avatarName: "Please, insert your avatarName",
    emptyEmail: "Please, insert your email address.",
    validEmail: "Please, insert a valid email.",
    //     emailAlreadyExists: "These email already exists.",
    emptyPassword: "Please, insert your password.",
    passwordConfirmationDifferent: "The passwords don't match.",
    passwordConfirmationRepeat: "Please, insert your password again.",
    gender: "Please, select your gender.",
    weakPassword: "Your password need to have at least one number, one lowercase word, one uppercase word and a symbol.",
    shortPassword: "Your password needs to have at least 8 characters.",
    acceptsTerms: "You need to accept our conditions terms to create your account.",
    fail: "Fail to create user.",
  });

  useEffect(() => { }, [error]);

  function validateEmail(email) {
    const EMAIL_REGEX =
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return EMAIL_REGEX.test(email);
  }

  function checkPasswordStrength(password) {
    if (password.length < 8) return 0;
    const regexes = [/[a-z]/, /[A-Z]/, /[0-9]/, /[~!@#$%^&*)(+=._-]/];
    return regexes
      .map((re) => re.test(password))
      .reduce((score, t) => (t ? score + 1 : score), 0);
  }

  const onChange = (e) => {
    let value;
    if (e.target.type === "checkbox") {
      value = e.target.checked;
    } else {
      value = e.target.value;
    }
    setSignUp({ ...signUp, [e.target.name]: value });
    validaForm();
  };

  const onLostFocus = (e) => {
    validaForm(e.target.name);
  };

  const validaForm = (field) => {
    let validForm = true;
    setError({
      name: "",
      avatarName: "",
      email: "",
      password: "",
      gender: "",
      acceptsTerms: "",
    });

    // Name errors
    if (signUp.name.length === 0 && (field === "name" || field === "")) {
      setError((prevState) => ({ ...prevState, name: erros.name }));
      validForm = false;
    }

    // Avatar Name errors
    if (signUp.avatarName.length === 0 && (field === "avatarName" || field === "")) {
      setError((prevState) => ({ ...prevState, avatarName: erros.avatarName }));
      validForm = false;
    }

    // Email errors
    if (signUp.email.length === 0 && (field === "email" || field === "")) {
      setError((prevState) => ({ ...prevState, email: erros.emptyEmail }));
      validForm = false;
    } else if (!validateEmail(signUp.email) && signUp.email.length !== 0 && (field === "email" || field === "")) {
      setError((prevState) => ({ ...prevState, email: erros.validEmail }));
      validForm = false;
    }

    // Password errors
    if (signUp.password.length === 0 && (field === "password" || field === "")) {
      setError((prevState) => ({
        ...prevState,
        password: erros.emptyPassword,
      }));
      validForm = false;
    } else if (
      checkPasswordStrength(signUp.password) === 0 &&
      signUp.password.length !== 0 && (field === "password" || field === "")) {
      setError((prevState) => ({ ...prevState, password: erros.weakPassword }));
      validForm = false;
    } else if (
      checkPasswordStrength(signUp.password) < 4 &&
      checkPasswordStrength(signUp.password) > 0 && (field === "password" || field === "")) {
      setError((prevState) => ({
        ...prevState,
        password: erros.shortPassword,
      }));
      validForm = false;
    }

    // Erros de Password Confirmation
    if (signUp.passwordConfirmation.length === 0 && (field === "passwordConfirmation" || field === "")) {
      setError((prevState) => ({
        ...prevState,
        passwordConfirmation: erros.passwordConfirmationRepeat,
      }));
      validForm = false;
    } else if (
      signUp.password !== signUp.passwordConfirmation &&
      signUp.passwordConfirmation.length !== 0 && (field === "passwordConfirmation" || field === "")) {
      setError((prevState) => ({
        ...prevState,
        password: erros.passwordConfirmationDifferent,
      }));
      validForm = false;
    }

    // Erro select gender
    if (signUp.gender === "" && (field === "gender" || field === "")) {
      setError((prevState) => ({
        ...prevState,
        gender: erros.gender,
      }));
      validForm = false;
    }

    // Erros de Accept Terms
    if (!signUp.acceptsTerms && (field === "acceptsTerms" || field === "")) {
      setError((prevState) => ({
        ...prevState,
        acceptsTerms: erros.acceptsTerms,
      }));
      validForm = false;
    }

    //     // Conta criada com Sucesso
    //     if(Object.keys(err).length === 0) {
    //         users.push(req.body)
    //         res.status(201).json({ message: sucesso.utilizador })
    //         return
    //     }

    return validForm;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (validaForm("")) {
      setLoading(true);
      const signUpProduct = await fetch("/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "authorization": `a ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(signUp),
      });
      const resJson = await signUpProduct.json();

      setTimeout(() => {
        if (signUpProduct.status === 201) {
          //localStorage.setItem("token", resJson.token);
          setSignUp({
            name: "",
            avatarName: "",
            email: "",
            password: "",
            passwordConfirmation: "",
            gender: "",
            acceptsTerms: false,
            subscribesNewsletter: false,
          });
          navigate("/login");
        } else {
          setLoading(false);
          setFail(erros.fail);
        }
      }, 3000);
    }
  };


  return (
    <div className={styles.hug}>
      <form onSubmit={(e) => onSubmit(e)} className={styles.centerSignUp}>
        <h1 className={styles.signUpHeader}>SignUp</h1>

        <div className={styles.submitLine}>
          <input
            type="text"
            placeholder="Name"
            name="name"
            value={signUp.name}
            onChange={(e) => onChange(e)}
            onBlur={(e) => onLostFocus(e)}
            className={styles.inputSignUpInformation}
          />
          <button className={styles.submitLente} type="button">
            {signUp.name.length === 0 && error.name.length === 0 ? (
              ""
            ) : error.name.length === 0 ? (
              <FontAwesomeIcon
                icon={faCheckCircle}
                className={styles.checkCircle}
              />
            ) : (
              <FontAwesomeIcon
                icon={faTimesCircle}
                className={styles.timesCircle}
              />
            )}
          </button>
        </div>
        <span className={styles.msg}>{error.name}</span>

        <div className={styles.submitLine}>
          <input
            type="text"
            placeholder="Avatar Name (max. 20 characters)"
            name="avatarName"
            value={signUp.avatarName}
            onChange={(e) => onChange(e)}
            onBlur={(e) => onLostFocus(e)}
            className={styles.inputSignUpInformation}
            maxLength="20"
          />
          <button className={styles.submitLente} type="button">
            {signUp.avatarName.length === 0 &&
              error.avatarName.length === 0 ? (
              ""
            ) : error.avatarName.length === 0 ? (
              <FontAwesomeIcon
                icon={faCheckCircle}
                className={styles.checkCircle}
              />
            ) : (
              <FontAwesomeIcon
                icon={faTimesCircle}
                className={styles.timesCircle}
              />
            )}
          </button>
        </div>
        <span className={styles.msg}>{error.avatarName}</span>

        <div className={styles.submitLine}>
          <input
            type="email"
            placeholder="Email"
            name="email"
            value={signUp.email}
            onChange={(e) => onChange(e)}
            onBlur={(e) => onLostFocus(e)}
            className={styles.inputSignUpInformation}
          />
          <button className={styles.submitLente} type="button">
            {signUp.email.length === 0 && error.email.length === 0 ? (
              ""
            ) : error.email.length === 0 ? (
              <FontAwesomeIcon
                icon={faCheckCircle}
                className={styles.checkCircle}
              />
            ) : (
              <FontAwesomeIcon
                icon={faTimesCircle}
                className={styles.timesCircle}
              />
            )}
          </button>
        </div>
        <span className={styles.msg}>{error.email}</span>

        <div className={styles.submitLine}>
          <input
            type={visiblePassword === false ? "password" : "text"}
            placeholder="Password"
            name="password"
            value={signUp.password}
            onChange={(e) => onChange(e)}
            onBlur={(e) => onLostFocus(e)}
            className={styles.inputSignUpInformation}
          />
          <button
            onClick={(e) => setVisiblePassword(!visiblePassword)}
            className={styles.submitLente}
            type="button"
          >
            {visiblePassword === true ? (
              <FontAwesomeIcon icon={faEye} />
            ) : (
              <FontAwesomeIcon icon={faEyeSlash} />
            )}
          </button>
        </div>
        <span className={styles.msg}>{error.password}</span>

        <div className={styles.submitLine}>
          <input
            type={visiblePasswordConfirmation === false ? "password" : "text"}
            placeholder="Confirm Password"
            name="passwordConfirmation"
            value={signUp.passwordConfirmation}
            onChange={(e) => onChange(e)}
            onBlur={(e) => onLostFocus(e)}
            className={styles.inputSignUpInformation}
          />
          <button
            onClick={(e) =>
              setVisiblePasswordConfirmation(!visiblePasswordConfirmation)
            }
            className={styles.submitLente}
            type="button"
          >
            {visiblePasswordConfirmation === true ? (
              <FontAwesomeIcon icon={faEye} />
            ) : (
              <FontAwesomeIcon icon={faEyeSlash} />
            )}
          </button>
        </div>
        <span className={styles.msg}>{error.passwordConfirmation}</span>

        <div className={styles.submitLine}>
          <select
            className={styles.inputSignUpInformation}
            onChange={(e) => onChange(e)}
            name="gender"
          >
            <option defaultValue selected={signUp.gender === ""}>
              Select Gender
            </option>
            <option value="male" selected={signUp.gender === "male"}>
              Male
            </option>
            <option value="female" selected={signUp.gender === "female"}>
              Female
            </option>
            <option value="none" selected={signUp.gender === "none"}>
              I prefer not to mention
            </option>
          </select>

        </div>
        <span className={styles.msg}>{error.gender}</span>

        <label className={`${styles.switch} ${styles.switchPlace}`}>
          <input
            type="checkbox"
            value={signUp.acceptsTerms}
            onChange={(e) => onChange(e)}
            name="acceptsTerms"
          />
          <span className={`${styles.slider} ${styles.round}`}></span>
        </label>
        <span className={styles.acceptsTerms}>Accepts Terms</span>
        <span className={styles.msgAcceptsTerms}>{error.acceptsTerms}</span>

        <label className={`${styles.switch} ${styles.switchPlace}`}>
          <input
            type="checkbox"
            value={signUp.subscribesNewsletter}
            onChange={(e) => onChange(e)}
            name="subscribesNewsletter"
          />
          <span className={`${styles.slider} ${styles.round}`}></span>
        </label>
        <span className={styles.subscribesNewsletter}>
          Subscribes Newsletter
        </span>

        <InputButton value="Send" type="submit" />
        {fail && <span className={styles.msg}>{fail}</span>}
      </form>
      <div>
        <img src={gif} className={styles.gif} />
      </div>
    </div>
  );
};

export default SignUp;

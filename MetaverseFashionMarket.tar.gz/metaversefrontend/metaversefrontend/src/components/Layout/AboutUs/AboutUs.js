import joana from "../../../imagemBanner/joana.png";
import monique from "../../../imagemBanner/monique.jpeg";
import marta from '../../../imagemBanner/marta.jpeg';
import styles from "./AboutUs.module.css";

const AboutUs = () => {
  return (
    <div className={styles.box}>
      <div className={styles.centerAbout}>
        <div className={styles.textHold}>
          <h1 className={styles.headerAboutUs}>About Us</h1>
          <h3 className={styles.titles}>Fashion is a way of expression. </h3>
          <p className={styles.text}>
          The urge of new and virtual worlds where we can be ourselves but without our physical limitations brought us a need to show our personality to others by any means. Believing that fashion can be mean to the aim we developed this online space, a market where you can dress up your avatar with pieces that match you! We just released our first collection designed by J. Morgado but there is more to come, our vision and expectations include partnerships with other designers and well-known brands to have the most diverse and inclusive wardrobe.
          </p>
          <h5 className={styles.titles}>
            Get dressed. The future is waiting for you.
          </h5>
        </div>
        <div>
          <div className={styles.photoHold}>
            <div className={styles.pic}>
              <img className={styles.photo} src={marta} alt="Marta Antunes"/>
              <p>Marta Antunes</p>
            </div>
            <div className={styles.pic}>
              <img className={styles.photo} src={monique} alt="Monique Alexandre" />
              <p>Monique Alexandre</p>
            </div>
            <div className={styles.pic}>
              <img className={styles.photo} src={joana}  alt="Joana Morgado"/>
              <p>J. Morgado</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutUs;

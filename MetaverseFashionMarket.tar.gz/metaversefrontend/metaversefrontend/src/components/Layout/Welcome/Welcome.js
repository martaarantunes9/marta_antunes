import { Link } from 'react-router-dom';
import welcome from '../../../imagemBanner/welcome.png';
import styles from './Welcome.module.css';


const Welcome = () => {
    return (
        <div>
            <div className={styles.op}>
                <div className={styles.image}>
                    <img className={styles.img} src={welcome} />
                </div>
                <div className={styles.p1}>
                    <div className={styles.head}>
                        <h1 className={styles.tittle}>Welcome to Metaverse Fashion Market</h1>
                    </div>
                    <h4>The real and the virtual, together wherever you go...</h4>
                    <div className={styles.body}>

                    </div>
                    <div className={styles.collectionAccess}>
                        <Link to="/collection" className={`${styles.but3} ${styles.collection}`}>View Collection</Link>
                        <Link to="/signup" className={styles.but1}>SignUp</Link>
                        <Link to="/login" className={styles.but2}>Login</Link>
                    </div>
                </div>
            </div>
        </div >
    )
}

export default Welcome;
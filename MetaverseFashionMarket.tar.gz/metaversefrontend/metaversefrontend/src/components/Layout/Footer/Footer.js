import styles from "./Footer.module.css";

const Footer = () => {
    return (
        <div className={styles.footerPage}>
            <h4>2022 Copyright &copy; -  Metaverse Fashion Market</h4>
        </div>
    )
}

export default Footer;
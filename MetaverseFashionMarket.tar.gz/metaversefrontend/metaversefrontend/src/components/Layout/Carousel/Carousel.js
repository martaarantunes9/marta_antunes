import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from 'react-responsive-carousel';

import CarouselItem from "./CarouselItem";

import styles from "./Carousel.module.css";

const CarouselImg = ({ add, collection, tryOnAvatar }) => {
  
  return (
    <div className={styles.divCarousel}>
        {collection.types.map((p, i) => (
            <section  key={i}>
                <h3 style={{margin: 30}}>{p.name}</h3>
             
                  {/* <div>
                    <img src={itens[0].image} width="80px" height="80px" />
                  </div> */}
                  <div className={styles.items}>
                    <Carousel
                    centerMode={true}
                    centerSlidePercentage= {75}
                    width={700}
                    infiniteLoop={true}
                    >
                        {p.products
                          .map((product, index) => (
                            <CarouselItem  
                              key={index} 
                              product={product} 
                              add={add}
                              tryOnAvatar={tryOnAvatar}
                             
                            />
                        ))} 
                    </Carousel>
                  </div>
            </section>
        ))}
    </div>
    
  );
};
 
export default CarouselImg; 
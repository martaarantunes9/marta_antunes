import styles from "./CarouselItem.module.css";

const CarouselItem = ({ product, add, tryOnAvatar }) => {


  return (
    <div className={styles.carouselItem} >
      <div className={styles.overlay}>
        {localStorage.getItem("token") && <button className={styles.btnDetail} onClick={(e) => add(product)}>Send to basket</button>}
        <button className={styles.tryIt} onClick={() => tryOnAvatar(product)}> Try !</button>

        <img
          src={product.img}
          className={styles.productImage}
          alt="product"
        />


        <p className={styles.productName}>{product.name}</p>
        <p className={styles.productPrice}>{JSON.stringify(product.price)} $</p>
      </div>

    </div>
  );
};



export default CarouselItem;


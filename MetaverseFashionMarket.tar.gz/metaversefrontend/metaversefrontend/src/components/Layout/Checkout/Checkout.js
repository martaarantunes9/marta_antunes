import React, { useState, useEffect } from "react";

import InputButton from "../InputButton/InputButton";
import Spinner from "../Spinner/Spinner";

import qrCode from "../../../imagemBanner/qRCode.png";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faEye,
  faEyeSlash,
  faCheckCircle,
  faTimesCircle,
} from "@fortawesome/free-solid-svg-icons";
import styles from "./Checkout.module.css";

const Checkout = () => {
  const [basket, setBasket] = useState({ basket: [] });
  const [selected, setSelected] = useState();
  const [visible, setVisible] = useState(false);
  const [paypalUser, setPaypalUser] = useState({
    email: "",
    password: "",
  });
  const [creditCardUser, setCreditCardUser] = useState({
    cardNumber: "",
    name: "",
    code: "",
    expiresAt: "",
    year: "",
  });

  const [error, setError] = useState({
    email: "",
    password: "",
    cardNumber: "",
    name: "",
    code: "",
    expiresAt: "",
    year: "",
  });

  const [erros, setErros] = useState({
    emptyEmail: "Please, insert your email address.",
    validEmail: "Please, insert a valid email.",
    emptyPassword: "Please, insert your password.",
    cardNumber: "Please, insert you credit card number.",
    name: "Please, insert your name.",
    code: "Please, insert the security code of the card.",
    expiresAt: "Please, select the month your card expires.",
    year: "Please, select the year your card expires.",
  });

  const [loading, setLoading] = useState(false);

  const [paymentSuccessfull, setPaymentSuccessfull] = useState(false);

  async function verifyBasket(token) {
    const collec = await fetch("/user/basket", {
      method: "GET",
      headers: {
        authorization: `a ${localStorage.getItem("token")}`,
      },
    });
    const res = await collec.json();
    setBasket(res);
  }

  useEffect(() => {
    verifyBasket();
  }, []);

  const checkout = async (basket) => {
    setLoading(true);
    const check = await fetch("/user/basket/checkout", {
      method: "DELETE",
      headers: {
        Authorization: `a ${localStorage.getItem("token")}`,
      },
    });
    const res = await check.json();

    const timeout = setTimeout(() => {
      if (check.status === 200) {
        setPaymentSuccessfull(true);
        setBasket(res);
      }
      setLoading(false);
    }, 3000);
    // clearTimeout(timeout);
  };

  if (!basket) {
    return null;
  }

  const totalPayment = () => {
    let total = 0;
    for (let i = 0; i < basket.basket.length; i++) {
      total = total + Number(basket.basket[i].price);
    }

    if (selected === "payPal") {
      total = total + total * (4 / 100);
    }

    return total;
  };

  const onChange = (e) => {
    setPaypalUser({ ...paypalUser, [e.target.name]: e.target.value });
    validaForm(e.target.name);
  };

  const onSelect = (e) => {
    setSelected(e.target.value);
    totalPayment();
  };

  const onCreditCardChange = (e) => {
    setCreditCardUser({ ...creditCardUser, [e.target.name]: e.target.value });
    validaForm(e.target.name);
  };

  function validateEmail(email) {
    const EMAIL_REGEX =
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return EMAIL_REGEX.test(email);
  }

  const validaForm = (field) => {
    let validForm = true;
    setError({
      email: "",
      password: "",
      cardNumber: "",
      name: "",
      code: "",
      expiresAt: "",
      year: "",
    });

    if (selected === "payPal") {
      // Email errors
      if (
        paypalUser.email.length === 0 &&
        (field === "email" || field === "")
      ) {
        setError((prevState) => ({ ...prevState, email: erros.emptyEmail }));
        validForm = false;
      } else if (
        !validateEmail(paypalUser.email) &&
        paypalUser.email.length !== 0 &&
        (field === "email" || field === "")
      ) {
        setError((prevState) => ({ ...prevState, email: erros.validEmail }));
        validForm = false;
      }

      // Password errors
      if (
        paypalUser.password.length === 0 &&
        (field === "password" || field === "")
      ) {
        setError((prevState) => ({
          ...prevState,
          password: erros.emptyPassword,
        }));
        validForm = false;
      }
    }

    if (selected === "creditCard") {
      if (
        creditCardUser.cardNumber.length === 0 &&
        (field === "cardNumber" || field === "")
      ) {
        setError((prevState) => ({
          ...prevState,
          cardNumber: erros.cardNumber,
        }));
        validForm = false;
      }
      if (
        creditCardUser.name.length === 0 &&
        (field === "name" || field === "")
      ) {
        setError((prevState) => ({ ...prevState, name: erros.name }));
        validForm = false;
      }

      if (
        creditCardUser.code.length === 0 &&
        (field === "code" || field === "")
      ) {
        setError((prevState) => ({ ...prevState, code: erros.code }));
        validForm = false;
      }

      if (
        creditCardUser.expiresAt === "" &&
        (field === "expiresAt" || field === "")
      ) {
        setError((prevState) => ({ ...prevState, expiresAt: erros.expiresAt }));
        validForm = false;
      }

      if (creditCardUser.year === "" && (field === "year" || field === "")) {
        setError((prevState) => ({ ...prevState, year: erros.year }));
        validForm = false;
      }
    }
    return validForm;
  };

  const onSubmit = (e) => {
    e.preventDefault();

    if (validaForm("")) {
      checkout(basket);
    }
  };

  if (loading) {
    return <Spinner />;
  } else {
    if (paymentSuccessfull) { 
      return <div className={styles.centerCheckout}>
                <div className={styles.notificationCheckout}>Thanks for your purchase!</div>
            </div>
    } else {
      return (
        <form onSubmit={onSubmit}>
          <div className={styles.centerCheckout}>
            {basket && basket.basket?.length > 0 ? (
              <div>
                <h1 className={styles.purchaseHeader}>
                  Choose your type of payment
                </h1>
                <table width="100%">
                  <thead className={styles.totalColor}>
                    <tr>
                      <th className={styles.firstColumn}>#</th>
                      <th className={styles.description}>Description</th>
                      <th className={styles.total}>Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    {basket &&
                      basket.basket &&
                      basket.basket.map((product, i) => (
                        <tr key={i}>
                          <td className={styles.firstColumn}>{i + 1}</td>
                          <td className={styles.description}>{product.name}</td>
                          <td className={styles.total}>{product.price}</td>
                        </tr>
                      ))}
                  </tbody>
                  <tfoot>
                    <tr className={styles.totalColor}>
                      <td colSpan="2" className={styles.totalBold}>
                        Total
                      </td>
                      <td className={styles.totalBold}>{totalPayment()}</td>
                    </tr>
                  </tfoot>
                </table>
                <div className={styles.payment}>
                  <span>
                    <input
                      type="radio"
                      id="Ethereum"
                      name="payment"
                      value="ethereum"
                      onChange={(e) => onSelect(e)}
                    />
                    <label htmlFor="Ethereum">Ethereum</label>
                  </span>
                  <span>
                    <input
                      type="radio"
                      id="CreditCard"
                      name="payment"
                      value="creditCard"
                      onChange={(e) => onSelect(e)}
                    />
                    <label htmlFor="CreditCard">Credit Card</label>
                  </span>
                  <span>
                    <input
                      type="radio"
                      id="PayPal"
                      name="payment"
                      value="payPal"
                      onChange={(e) => onSelect(e)}
                    />
                    <label htmlFor="PayPal">PayPal (+4% fee)</label>
                  </span>
                </div>
                {selected === "creditCard" && (
                  <div className={styles.cardInfo}>
                    <input
                      id="cardNumber"
                      type="text"
                      name="cardNumber"
                      value={creditCardUser.cardNumber}
                      placeholder="Card Number"
                      className={styles.inputInfoCheckout}
                      onChange={(e) => onCreditCardChange(e)}
                    />
                    <span className={styles.msgCheckout}>
                      {error.cardNumber}
                    </span>

                    <span className={styles.nameCode}>
                      <input
                        id="cardName"
                        type="text"
                        name="name"
                        value={creditCardUser.name}
                        placeholder="Card holder name"
                        className={styles.name}
                        onChange={(e) => onCreditCardChange(e)}
                      />
                      <input
                        id="cardNumber"
                        type="number"
                        name="code"
                        value={creditCardUser.code}
                        placeholder="CV"
                        className={styles.code}
                        onChange={(e) => onCreditCardChange(e)}
                      />
                    </span>
                    <span className={styles.msgCheckout}>{error.name}</span>
                    <span className={styles.msgCheckout}>{error.code}</span>

                    <span className={styles.nameCode}>
                      <select
                        id="expiresAt"
                        name="expiresAt"
                        className={styles.selectExpires}
                        onChange={(e) => onCreditCardChange(e)}
                      >
                        <option
                          defaultValue
                          selected={creditCardUser.expiresAt === ""}
                        >
                          Expires at
                        </option>
                        <option
                          value="january"
                          selected={creditCardUser.expiresAt === "january"}
                        >
                          January
                        </option>
                        <option
                          value="february"
                          selected={creditCardUser.expiresAt === "february"}
                        >
                          February
                        </option>
                        <option
                          value="march"
                          selected={creditCardUser.expiresAt === "march"}
                        >
                          March
                        </option>
                        <option
                          value="april"
                          selected={creditCardUser.expiresAt === "april"}
                        >
                          April
                        </option>
                        <option
                          value="may"
                          selected={creditCardUser.expiresAt === "may"}
                        >
                          May
                        </option>
                        <option
                          value="june"
                          selected={creditCardUser.expiresAt === "june"}
                        >
                          June
                        </option>
                        <option
                          value="july"
                          selected={creditCardUser.expiresAt === "july"}
                        >
                          July
                        </option>
                        <option
                          value="august"
                          selected={creditCardUser.expiresAt === "august"}
                        >
                          August
                        </option>
                        <option
                          value="september"
                          selected={creditCardUser.expiresAt === "september"}
                        >
                          September
                        </option>
                        <option
                          value="october"
                          selected={creditCardUser.expiresAt === "october"}
                        >
                          October
                        </option>
                        <option
                          value="november"
                          selected={creditCardUser.expiresAt === "november"}
                        >
                          November
                        </option>
                        <option
                          value="december"
                          selected={creditCardUser.expiresAt === "december"}
                        >
                          December
                        </option>
                      </select>

                      <select
                        id="year"
                        name="year"
                        className={styles.selectYear}
                        onChange={(e) => onCreditCardChange(e)}
                      >
                        <option
                          defaultValue
                          selected={creditCardUser.year === ""}
                        >
                          Year
                        </option>
                        <option
                          value="2022"
                          selected={creditCardUser.year === "2022"}
                        >
                          2022
                        </option>
                        <option
                          value="2023"
                          selected={creditCardUser.year === "2023"}
                        >
                          2023
                        </option>
                        <option
                          value="2024"
                          selected={creditCardUser.year === "2024"}
                        >
                          2024
                        </option>
                        <option
                          value="2025"
                          selected={creditCardUser.year === "2025"}
                        >
                          2025
                        </option>
                        <option
                          value="2026"
                          selected={creditCardUser.year === "2026"}
                        >
                          2026
                        </option>
                      </select>
                    </span>
                    <span className={styles.msgCheckout}>
                      {error.expiresAt}
                    </span>
                    <span className={styles.msgCheckout}>{error.year}</span>
                  </div>
                )}
                {selected === "payPal" && (
                  <div className={styles.cardInfo}>
                    <div className={styles.submitLine}>
                      <input
                        type="email"
                        className={styles.inputInfoCheckout}
                        placeholder="Email"
                        name="email"
                        value={paypalUser.email}
                        onChange={(e) => onChange(e)}
                      />
                      <button className={styles.submitLente} type="button">
                        {paypalUser.email.length === 0 &&
                        error.email.length === 0 ? (
                          ""
                        ) : error.email.length === 0 ? (
                          <FontAwesomeIcon
                            icon={faCheckCircle}
                            className={styles.checkCircle}
                          />
                        ) : (
                          <FontAwesomeIcon
                            icon={faTimesCircle}
                            className={styles.timesCircle}
                          />
                        )}
                      </button>
                    </div>
                    <span className={styles.msgCheckout}>{error.email}</span>

                    <div className={styles.submitLine}>
                      <input
                        type={visible === false ? "password" : "text"}
                        className={styles.inputInfoCheckout}
                        placeholder="Password"
                        name="password"
                        value={paypalUser.password}
                        onChange={(e) => onChange(e)}
                      />
                      <button
                        onClick={(e) => setVisible(!visible)}
                        className={styles.submitLente}
                        type="button"
                      >
                        {visible === true ? (
                          <FontAwesomeIcon icon={faEye} />
                        ) : (
                          <FontAwesomeIcon icon={faEyeSlash} />
                        )}
                      </button>
                    </div>
                    <span className={styles.msgCheckout}>{error.password}</span>
                  </div>
                )}
                {selected === "ethereum" && (
                  <div className={styles.qrCode}>
                    <img
                      src={qrCode}
                      style={{ height: "150px", marginTop: "20px" }}
                    />
                  </div>
                )}
                <InputButton value="Payment" />
              </div>
            ) : (
              <p className={styles.notificationCheckout}>No products found!</p>
            )}
          </div>
        </form>
      );
    }
  }
};

export default Checkout;

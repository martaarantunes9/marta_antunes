import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from "react-router-dom";

import InputButton from '../InputButton/InputButton';

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
    faTrashAlt
} from "@fortawesome/free-solid-svg-icons";
import styles from './Basket.module.css';

const Basket = () => {
    let navigate = useNavigate();

    const [basket, setBasket] = useState({ basket: [] });

    const removeFromBasket = async (product) => {
        setBasket(prevState => ({
            ...prevState,
            basket: prevState.basket.filter((item) => item._id !== product._id)
        }))

        let res = await fetch("/basket", {
            method: "PATCH",
            headers: {
                "Content-Type": "application/json",
                "authorization": `a ${localStorage.getItem('token')}`
            },
            body: JSON.stringify(basket.basket)
        })
        let retorno = res.status === 200 ? "Sucesso" : "Falha"
    }

    async function verifyBasket(token) {
        const collec = await fetch("/user/basket", {
            method: "GET",
            headers: {
                "authorization": `a ${localStorage.getItem('token')}`
            }
        });
        const res = await collec.json();
        setBasket(res);
    }

    useEffect(() => {
        verifyBasket()
    }, [])

    if (!basket) {
        return null
    }

    const checkout = async (basket) => {
        navigate("/checkout");
    }

    const totalPayment = () => {
        let total = 0;
        for (let i = 0; i < basket.basket.length; i++) {
            total = total + Number(basket.basket[i].price);
        }
        return total;
    };

    return (
        <div className={styles.centerTable}>
            {basket && basket.basket?.length > 0 ? (
                <div>
                    <h1 className={styles.purchaseHeader}>Confirm your Purchase</h1>
                    <table width="100%">
                        <thead>
                            <tr className={styles.totalQuantityColor}>
                                <th className={styles.firstColumn}>#</th>
                                <th className={styles.description}>Description</th>
                                <th className={styles.total}>Price</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            {basket && basket.basket && basket.basket.map((product, i) => (
                                <tr key={i}>
                                    <td className={styles.firstColumn}>{i + 1}</td>
                                    <td className={styles.description}>{product.name}</td>
                                    <td className={styles.total}>{product.price}</td>
                                    <td className={styles.spaceTrash}>
                                        <button 
                                            className={styles.btnTrash}>
                                            <FontAwesomeIcon icon={faTrashAlt} className={styles.trash} />
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                        <tfoot>
                            <tr className={styles.totalQuantityColor}>
                                <td colSpan="2" className={styles.totalBold}>
                                    Total
                                </td>
                                <td className={styles.totalBold}>{totalPayment()}</td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                    <InputButton
                        value="Checkout"
                        onClick={() => checkout(basket)}
                        disabled={basket.basket.length <= 0}
                    />
                </div>
            ) : (
                <p className={styles.notification}>No products found!</p>
            )}
        </div>

    )
}

export default Basket;
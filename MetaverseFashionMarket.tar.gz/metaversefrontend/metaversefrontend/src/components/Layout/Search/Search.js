import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import styles from './Search.module.css';

const Search = ({ onChange, text }) => {

    return (
        <form>
            <div className={styles.submitLine}>
                    <input 
                        value={text}
                        type="text"
                        placeholder="Search" 
                        onChange={(e) => onChange(e)}
                        className={styles.inputInformation}
                    />
                    <button 
                        className={styles.submitLente} 
                        type="button"
                    >
                        <FontAwesomeIcon icon={ faSearch } />    
                    </button>
                </div>
        </form>
    )
}

export default Search;
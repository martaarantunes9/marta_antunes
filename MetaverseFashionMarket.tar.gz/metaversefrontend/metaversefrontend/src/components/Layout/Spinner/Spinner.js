import React from 'react';

import load from "../../../imagemBanner/load.png";
import styles from './Spinner.module.css';

const Spinner = () => {
    return (
        <div className={styles.centerLoad}>
            <img 
                src={load} 
                className={styles.load} />
        </div>
    ) 
}

export default Spinner;
import styles from './InputButton.module.css';

const InputButton = ({value, type, onClick, disabled}) => {

    return (
        <button 
            type={type} 
            onClick={onClick}
            className={styles.btn}
            // disabled={disabled} 
        >
            {value} 
        </button>
    )
}

export default InputButton;
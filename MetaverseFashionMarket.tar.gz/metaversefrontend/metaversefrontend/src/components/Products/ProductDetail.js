const ProductDetail = () => {
    return (
        <div>
            <img />
            <h3></h3>
            <p>Available: </p>
        </div>
    )
}

export default ProductDetail;
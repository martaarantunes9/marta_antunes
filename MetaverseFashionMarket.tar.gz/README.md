# projetoFinal 
Metafashion


Before running frontend you must install these extensions:

1.Sticky library for React
    npm install react-sticky-el

2.React-responsive-carousel
    npm i react-responsive-carousel
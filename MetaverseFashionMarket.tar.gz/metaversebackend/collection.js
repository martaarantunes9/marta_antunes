const { ObjectId } = require("mongodb")
const { getMongoCollection } = require("./db")
async function insertProduct(product){
    const collection = await getMongoCollection("ProjetoFinal", "Collection")
      const res = await collection.insertOne(product)
      return res.insertedId


}

async function insertCollection(roupinha){
    const collection = await getMongoCollection("ProjetoFinal", "Collection")
    const res = await collection.insertOne(roupinha)
    return res.insertedId
}
async function findCollection(){
    const collection = await getMongoCollection("ProjetoFinal", "Collection") 
    const collectionTotal = await collection.find().toArray()

    return collectionTotal
}

async function findTypes(cid){
    if(!ObjectId.isValid(cid)) return null 
    const collection = await getMongoCollection("ProjetoFinal", "Types")
    let typesTotal = await collection.find({CollectionId: ObjectId(cid)}).toArray()
    return typesTotal
}


async function findProducts(cid,tid){
    if(!ObjectId.isValid(cid) || !ObjectId.isValid(tid) ) return null 

    const collection = await getMongoCollection("ProjetoFinal", "Products")
    let productsTotal = await collection.find(
        {$and:[{CollectionId: ObjectId(cid)},{TypeId: ObjectId(tid)}]}).toArray()
    return productsTotal
}


async function findProductById(id){
    const collection = await getMongoCollection("ProjetoFinal", "Collection")
    let produto =  await collection.findOne({_id: ObjectId(id)})
    return produto
}


module.exports = { 
    insertProduct,
    findCollection,
    findProductById,
    findTypes,
    findProducts,
    insertCollection
 }

const express = require('express');
const app = express();
const port = process.env.PORT ?? 3003
const {
    insertUser,
    findUserByEmail,
    insertSession,
    findUserById,
    updateSession,
    findSessionByToken
} = require("./db")
const {
    insertCollection,
    findTypes,
    findCollection,
    findProducts,
} = require("./collection")

const { updateBasket, clearBasket, updateAvatar, clearAvatar } = require("./stock");
app.use(express.json());

async function verifyUser(req, res, next) {

    const auth = req.headers.authorization?.split(' ') ?? []

    if (auth.length > 0) {
        const session = await findSessionByToken(auth[1])
        if (session && session.expiresAt > new Date()) {
            await updateSession(session._id)
            req.user = await findUserById(session.userId);
            next()
        } else {
            res.sendStatus(401)
        }
    } else {
        res.sendStatus(401)
    }
}


// MÃ‰TODOS SIGNUP E LOGIN-----------------------------------------------------------------------------------------

/* USER : req.body = {
    avatarName: string,
    email: string , 
    password: string , 
    passwordConfrimation: string , 
    acceptsTerms: boolean , 
    subscribesNewsletter: boolean 
    basket: 
} 
*/
app.post("/signup", async (req, res) => {
    const errors = await validateNewUser(req.body)
    if (Object.keys(errors).length === 0) {
        // Criar utilizador
        const { passwordConfirmation, ...user } = req.body
        const id = await insertUser(user)
        res.status(201).json({
            "message": "User created!",
            "_id": id
        })
        return
    }
    res.status(400).json({
        message: "Data is not valid.",
        errors
    })
})

app.post("/login", async (req, res) => {
    const { email, password } = req.body

    const user = await findUserByEmail(email)
    if (!user)
        return res
            .status(404)
            .json({ "message": "User not found!" })

    if (user.password !== password)
        return res
            .status(401)
            .json({ "message": "Password is not valid!" })

    const token = await insertSession(user._id)
    res.status(200).json({ token })
})

app.get("/user", verifyUser, (req, res) => {
    res
        .status(200)
        .json(req.user)
})



//FIM DE MÃ‰TODOS  SIGNUP E LOGIN ------------------------------------------------------------------


// ---- INÃCIO MÃ‰TODOS COLEÃ‡ÃƒO ----------------------------------
/*PRODUCT: { 
        type: String ,
        name: String,
        price: number,
        color: String,
        gender: String,
        tags: []
        
}
*/



// MÃ‰TODO Collection
/*
POST /collection (cria colecao)
POST /collection/:cid/type (cria tipo)
POST /collection/:cid/type/:tid/product (cria produto)*/

app.post('/collection', async (req, res) => {
    const roupinha = req.body
    const cid = await insertCollection(roupinha)

    res.status(201).json({
        "message": "Product added!",
        "_id": id,
        "cid": cid,


    })

})


// Dá-nos o tipo
app.get('/collection/:cid/type', async (req, res) => {
    const { cid } = req.params
    const typesTotal = await findTypes(cid)
    res.status(200).json(typesTotal)

})
//Dá-nos o array de produtos que integram o tipo
app.get('/collection/:cid/type/:tid/product', async (req, res) => {
    const { cid, tid } = req.params
    const list = await findProducts(cid, tid)

    res.status(200).json(list)
})
app.get('/collection', async (req, res) => {
    const collections = await findCollection()
    for (const collection of collections) {
        collection.types = await findTypes(collection._id)
        for (const type of collection.types) {
            type.products = await findProducts(collection._id, type._id)
        }
    }
    res.status(200).json(collections)
})






// ATUALIZA BASKET a cada click no botão "send to basket"
app.patch('/basket', verifyUser, async (req, res) => {
    let atualizado = await updateBasket(req.user._id, req.body.basket)
    let basketAtualizado = await findUserById(req.user._id)

    res.status(200).json(basketAtualizado)
})

//GET BASKET
app.get('/user/basket', verifyUser, (req, res) => {
    res.status(200).json({ basket: req.user.basket })
})


// ATUALIZAR AVATAR a cada click no botão "Try it!"
app.patch('/user/avatar', verifyUser, async (req, res) => {
    let atualizado = await updateAvatar(req.user._id, req.body.avatar)
    let avatarVestido = await findUserById(req.user._id)

    res.status(200).json(avatarVestido)
})

// GET AVATAR
app.get('/user/avatar', verifyUser, (req, res) => {
    res.status(200).json({ avatar: req.user.avatar })
})
app.delete('/user/clear', verifyUser, async (req, res) => {

    if (req.user.avatar.length === 0) {
        res.status(404).json({ message: "Your avatar is naked." })
    }
    else {
        await clearAvatar(req.user._id)
        res.status(200).json({ message: "Products removed." })
        return clearAvatar
    }
})


app.delete('/user/basket/checkout', verifyUser, async (req, res) => {

    if (req.user.basket.length === 0) {
        res.status(404).json({ message: "Your basket is empty." })
    }
    else {
        await clearBasket(req.user._id)
        res.status(200).json({ message: "Products removed from collection. Stock updated." })
        return clearBasket
    }
})





// ------ FIM MÃ‰TODOS COLEÃ‡ÃƒO-------------------------------



// FUNÃ‡Ã•ES DE SIGNUP E LOGIN -----------------------------------------------------------------------


async function validateNewUser(data) {
    const errors = {}
    if (data.avatarName === 10) {
        errors.name = "Your Avatar Name cannot have more than 10 characters."
    }

    if (/[0123456789]/.test(data.name)) {
        errors.name = "Please insert a valid name."
    }

    if (data.email === undefined || data.email.length === 0) {
        errors.email = "Please insert your email."
    } else if (!validateEmail(data.email)) {
        errors.email = "Please insert a valid email."
    } else if (Boolean(await findUserByEmail(data.email))) {
        errors.email = "This email had already been registered."
    }

    if (data.password === undefined) {
        errors.password = "Please insert your password."
    } else {
        const passwordStrength = checkPasswordStrength(data.password)
        if (data.password.length === 0) {
            errors.password = "Please insert your password."
        } else if (passwordStrength === 0) {
            errors.password = " Password should contain at least 8 characters."
        } else if (passwordStrength < 4) {
            errors.password = "Your password must have at least a number, a lower case and an upper case."
        }
    }

    if (data.passwordConfirmation === undefined || data.passwordConfirmation.length === 0) {
        errors.passwordConfirmation = "Please insert your password again."
    } else if (data.password !== data.passwordConfirmation) {
        errors.passwordConfirmation = "Passwords do not match."
    }

    if (!data.acceptsTerms) {
        errors.acceptsTerms = "You have to accept terms to proceed."
    }

    return errors
}


function validateEmail(email) {
    const EMAIL_REGEX = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    return EMAIL_REGEX.test(email)
}

function checkPasswordStrength(password) {
    if (password.length < 8) return 0;
    const regexes = [
        /[a-z]/,
        /[A-Z]/,
        /[0-9]/,
        /[~!@#$%^&*)(+=._-]/
    ]
    return regexes
        .map(re => re.test(password))
        .reduce((score, t) => t ? score + 1 : score, 0)
}

// FIM DE FUNÃ‡Ã•ES DE SIGNUP -----------------------------------------------------------------------------------------


app.listen(port, () => console.log(`A escuta em http://localhost:${port}`));

const { ObjectId } = require("mongodb")
const {getMongoCollection} = require("./db")

async function updateBasket(id, basket){
    const collection = await getMongoCollection("ProjetoFinal", "users")
    console.log(basket)
    const carrinho = await collection.updateOne(
        {_id: ObjectId(id)}, // isto é um .find() e encontra o user
        {
            $push:{basket: basket}
        }
    )
    console.log(carrinho)
    return carrinho

}

async function updateAvatar(id, avatar){
    const collection = await getMongoCollection("ProjetoFinal", "users")
    console.log(avatar)
    const selectedClothes = await collection.updateOne(
        {_id: ObjectId(id)}, // isto é um .find() e encontra o user
        {
            $push:{avatar: avatar}
        }
    )
    console.log(selectedClothes)
    return selectedClothes

}

async function getBasket(id){
    const collection = await getMongoCollection("ProjetoFinal", "users")
    const carrinho = await collection.find({_id: ObjectId(id).basket}).toArray()
    console.log(carrinho)
    return carrinho
}



async function clearBasket(id){
    const collection  = await getMongoCollection("ProjetoFinal", "users")
    const clearUserBasket = await collection.updateOne(
        {_id:ObjectId(id)},
        { $set: { basket: [] } }

    )
    return clearUserBasket

}



async function clearAvatar(id){
    const collection  = await getMongoCollection("ProjetoFinal", "users")
    const clearUserAvatar = await collection.updateOne(
        {_id:ObjectId(id)},
        { $set: { avatar: [] } }

    )
    return clearUserAvatar

}

module.exports = {
updateBasket,
getBasket,
clearBasket,
updateAvatar,
clearAvatar
}
const { MongoClient, ObjectId } = require('mongodb');
const URL = process.env.MONGO_URL ?? "mongodb://localhost:27017"

const DATABASE_NAME = "ProjetoFinal"
const USER_COLLECTION = "users"
const SESSION_COLLECTION = "sessions"


let client
async function connectToMongo() {
    try {
        if (!client) {
            client = await MongoClient.connect(URL);
        }
        return client;
    } catch (err) {
        console.log(err);
    }
}

async function getMongoCollection(dbName, collectionName) {
    const client = await connectToMongo();
    return client.db(dbName).collection(collectionName)
}


// -------- SIGN UP ---------
async function insertUser(user) {
    const collection = await getMongoCollection(DATABASE_NAME, USER_COLLECTION)
    const res = await collection.insertOne(user)
    return res.insertedId
}

async function findUserByEmail(email) {

    const collection = await getMongoCollection(DATABASE_NAME, USER_COLLECTION)
    const user = await collection.findOne({ email })
    return user
}

async function findUserById(id){
    const collection = await getMongoCollection(DATABASE_NAME, USER_COLLECTION)
    const user = await collection.findOne({_id: ObjectId(id)})
    console.log(user)
    return user
}





// --------- SESSION -----------------
async function insertSession(id) {
    const collection = await getMongoCollection(DATABASE_NAME, SESSION_COLLECTION)
    const res = await collection.insertOne({
        userId: id,
        expiresAt: new Date(new Date().valueOf() + (60 * 60 * 1000))
    })
    return res.insertedId
}

async function findSessionByToken(token) {
    if (!ObjectId.isValid(token)) return undefined
    const collection = await getMongoCollection(DATABASE_NAME, SESSION_COLLECTION)
    const session = await collection.findOne({_id: new ObjectId(token)})
    return session
}


async function updateSession(id){
    const collection = await getMongoCollection(DATABASE_NAME, SESSION_COLLECTION)
    
    const newSession = await collection.updateOne(
        {_id: ObjectId(id)}, // .find()
     {
         $set: {
            expiresAt: new Date(new Date().valueOf() + (60 * 60 * 1000))
        }
    }
    
    )
    return newSession

}




module.exports = {
    connectToMongo,
    getMongoCollection,
    insertUser,
    findUserByEmail,
    insertSession,
    findSessionByToken,
    findUserById,
    updateSession
    
}
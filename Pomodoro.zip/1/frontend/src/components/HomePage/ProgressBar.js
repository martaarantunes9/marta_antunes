// import "./Progressbar.css"
// import HomePage from "./HomePage"

// export default function ProgressBar(Timer){

//     const num = document.querySelector(".number");
//     let counter = 0;
//     setInterval(() => {
//       if (counter == 100) {
//         clearInterval();
//       } else {
//         counter += 1;
//         num.textContent = counter + ;
//       }
//     }, 35);
  
//           return (
//           <div class="container">
//             <div class="bar">
//               <svg>
//                  <circle cx="50%" cy="50%" r="90%"></circle>
//               </svg>
//               <h1 class="number">0%</h1>
//             </div>
//           </div>
//           );
//   }